<?php 
require_once AJ_PLUGIN_PATH . '/includes/class.iota.php';
require_once AJ_PLUGIN_PATH . '/includes/functions.php';
?>