For installation instructions see:
http://www.ecologie.io/2017/10/06/introducing-the-ecologie-io-wordpress-microtipping-plugin/
